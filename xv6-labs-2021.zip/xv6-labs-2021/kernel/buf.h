struct buf {
  int valid;   // has data been read from disk? 有效位
  int disk;    // does disk "own" buf?
  uint dev; 
  uint blockno;//block number
  struct sleeplock lock;//睡眠锁
  uint refcnt;
  struct buf *prev; // LRU cache list
  struct buf *next;
  uchar data[BSIZE];
  uint lastuse;
};

