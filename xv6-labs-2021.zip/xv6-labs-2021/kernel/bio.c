// Buffer cache.
//
// The buffer cache is a linked list of buf structures holding
// cached copies of disk block contents.  Caching disk blocks
// in memory reduces the number of disk reads and also provides
// a synchronization point for disk blocks used by multiple processes.
//
// Interface:
// * To get a buffer for a particular disk block, call bread.
// * After changing buffer data, call bwrite to write it to disk.
// * When done with the buffer, call brelse.
// * Do not use the buffer after calling brelse.
// * Only one process at a time can use a buffer,
//     so do not keep them longer than necessary.


#include "types.h"
#include "param.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "riscv.h"
#include "defs.h"
#include "fs.h"
#include "buf.h"

struct { 
  struct spinlock lock;
  struct buf buf[BUFFERSIZE];
} bcachebucket[BUCKETSIZE];

void
binit(void)
{
  for (int i = 0; i < BUCKETSIZE; i++)
  {
    initlock(&bcachebucket[i].lock, "bcachebucket");
    for (int j = 0; j < BUFFERSIZE; j++)
    {
      initsleeplock(&bcachebucket[i].buf[j].lock, "buffer");
    }
  }

}

// Look through buffer cache for block on device dev.
// If not found, allocate a buffer.
// In either case, return locked buffer.
static struct buf*
bget(uint dev, uint blockno)
{
  struct buf *b;
  // 申请桶的锁
  int bucket=HASH(blockno);
  acquire(&bcachebucket[bucket].lock);
  // 遍历该桶的buffer，查找对应blockno、dev的buffer
  for(int i=0;i<BUFFERSIZE;i++){
    b=&bcachebucket[bucket].buf[i];
    if(b->dev==dev && b->blockno == blockno){
      b->refcnt++;
      // 一旦找到buffer，设置最近一次使用的ticks
      b->lastuse=ticks; 
      release(&bcachebucket[bucket].lock);
      // 对buffer块加睡眠锁
      acquiresleep(&b->lock);
      return b;
    }
  }

  // buffer未命中
  // 遍历查找该桶最近最少使用的空闲buffer（ticks比较小）
  uint flag=0xffffffff;//最大的unsigned int
  int idx=-1;
  for(int i=0;i<BUFFERSIZE;i++){
    b=&bcachebucket[bucket].buf[i];
    if(b->refcnt==0 && b->lastuse<flag){
      flag=b->lastuse;
      idx=i;
    }
  }

  // // 若没有空闲块，即每一个buffer的refcnt均不为0
  // if(idx==-1){
  //   // 优化：去邻居bucket偷取空闲buffer
  //   panic("bget:no unused buffer for recycle");
  // }
  if (idx == -1) {
    int neighbor_buckets[2] = {-1, -1};
    if (bucket > 0) {
      neighbor_buckets[0] = bucket - 1; // 前一个邻居桶
    }
    if (bucket < BUCKETSIZE - 1) {
      neighbor_buckets[1] = bucket + 1; // 后一个邻居桶
    }

    for (int n = 0; n < 2; n++) {
      if (neighbor_buckets[n] != -1) {
        int neighbor_bucket = neighbor_buckets[n];
        acquire(&bcachebucket[neighbor_bucket].lock);
        for (int i = 0; i < BUFFERSIZE; i++) {
          b = &bcachebucket[neighbor_bucket].buf[i];
          if (b->refcnt == 0) {
            // 找到一个空闲缓冲区，将其移到当前桶
            memmove(&bcachebucket[bucket].buf[idx], b, sizeof(struct buf));
            memset(b, 0, sizeof(struct buf)); // 清空邻居桶的缓冲区
            release(&bcachebucket[neighbor_bucket].lock);
            // 更新索引
            idx = i;
            break;
          }
        }
        if (idx != -1) {
          // 如果找到了空闲缓冲区，退出循环
          break;
        }
        release(&bcachebucket[neighbor_bucket].lock);
      }
    }
    if (idx == -1) {
        // 如果邻居桶中也没有空闲的缓冲区，报错
        panic("bget:no unused buffer for recycle");
    }
}

  // 对该空闲buffer初始化
  b = &bcachebucket[bucket].buf[idx];
  b->dev=dev;
  b->blockno=blockno;
  b->lastuse=ticks;
  b->valid=0;
  b->refcnt=1;
  release(&bcachebucket[bucket].lock);
  acquiresleep(&b->lock);
  return b;
}
// Return a locked buf with the contents of the indicated block.
// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
  if(!holdingsleep(&b->lock))
    panic("bwrite");
  virtio_disk_rw(b, 1);
}

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
  if(!holdingsleep(&b->lock))
    panic("brelse");

  releasesleep(&b->lock);

  uint bucket = HASH(b->blockno);
  acquire(&bcachebucket[bucket].lock);
  b->refcnt--;
  if (b->refcnt == 0) {
    b->lastuse = ticks; // 如果当前缓冲块没有被引用，释放该区域时更新上次释放的时间
  }
  release(&bcachebucket[bucket].lock);
}
void
bpin(struct buf *b) {
  uint bucket = HASH(b->blockno);
  acquire(&bcachebucket[bucket].lock);
  b->refcnt++;
  release(&bcachebucket[bucket].lock);
}

void
bunpin(struct buf *b) {
  uint bucket = HASH(b->blockno);
  acquire(&bcachebucket[bucket].lock);
  b->refcnt--;
  release(&bcachebucket[bucket].lock);
}


