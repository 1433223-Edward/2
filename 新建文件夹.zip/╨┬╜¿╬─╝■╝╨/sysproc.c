#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "pstat.h"
#include "stat.h"

int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

int 
sys_settickets(void) {
  int number;
  argint(0, &number); //0相当于寄存器，也就是把从用户空间中的参数取出存放到内核空间上
                      //【testTickets中传入settickets()的参数存到寄存器中了】
  if(number < 0) {
    return -1;
  }
  else if(number == 0) {  
    return settickets(InitialTickets);  //InitialTickets要定义在param.h中,相当于默认为5个
  }
  else {
    return settickets(number);
  }
  //转到proc.c中来进一步实现settickets();
}

int 
sys_getpinfo(void) {
  struct pstat *ps;
  if (argptr(0, (char **)&ps, sizeof(struct pstat)) < 0) {
    //这行代码使用 argptr 函数检查第一个参数（索引为0）是否是一个有效的用户空间指针。
    //argptr 函数确保这个指针指向足够大的内存空间来存储一个 pstat 结构体。
    return -1;
  }
  getpinfo(ps);
  return 0;
}

