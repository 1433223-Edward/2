#ifndef _PSTAT_H_
#define _PSTAT_H_

#include "param.h"


struct pstat
{
    int inuse[NPROC];  // 表示进程所处状态，1为可运行，0为阻塞
    int ticket[NPROC]; // 表示该进程拥有的彩票数
    int pid[NPROC];    // 表示每个进程的进程ID大小
    int tick[NPROC];   // 表示每个进程积累的时间片
};

#endif // _PSTAT_H_

// int inuse[NPROC];  // whether this slot of the process table is in use (1 or 0)
    // int ticket[NPROC]; // the number of tickets this process has
    // int pid[NPROC];    // the PID of each process
    // int tick[NPROC];   // the number of ticks each process has accumulated
