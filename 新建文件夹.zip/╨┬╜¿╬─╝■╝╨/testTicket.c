#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char * argv[]) {
    int number = atoi(argv[1]);  //接受一个整数参数作为命令行参数，但是原本格式为字符串，需要转化成int型
    //给进程设置彩票数
    settickets(number);  //设置当前进程的票数为给定的值

    while(1) {
        /*
            停顿一下
        */
    }
    exit();
}

